

<html>
    <head>
        <title>Hello World</title>
    </head>
    <body>
        <?php
            echo("Hello World (in PHP!)");
        ?>
    </body>
</html>
